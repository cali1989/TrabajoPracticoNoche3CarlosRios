package repositories;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


import connectors.Connector;
import entities.Paquete;

public class PaqueteRepository {
    private Connection conn = Connector.getConnection();

    public void save(Paquete paquete) {
        if (paquete == null)
            return;
        try (PreparedStatement ps = ((java.sql.Connection) conn).prepareStatement(
                "INSERT INTO Paquetes (nombre, descripcion, precio, idDestino) VALUES (?, ?, ?, ?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, paquete.getNombre());
            ps.setString(2, paquete.getDescripcion());
            ps.setDouble(3, paquete.getPrecio());
            ps.setInt(4, paquete.getIdDestino());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                paquete.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Paquete paquete) {
        if (paquete == null)
            return;
        try (PreparedStatement ps = ((java.sql.Connection) conn).prepareStatement(
                "DELETE FROM Paquetes WHERE id = ?")) {
            ps.setInt(1, paquete.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Paquete> getAll() {
        List<Paquete> list = new ArrayList();
        try (ResultSet rs =  conn
                .createStatement()
                .executeQuery("SELECT * FROM Paquetes")) {
            while (rs.next()) {
                list.add(new Paquete(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("descripcion"),
                        rs.getDouble("precio"),
                        rs.getInt("idDestino")));
                        
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Paquete getById(int id) {
        return getAll()
                .stream()
                .filter(paquete -> paquete.getId() == id)
                .findFirst()
                .orElse(new Paquete());
    }

    public List<Paquete> getPaquetesByDestino(int idDestino) {
        return getAll()
                .stream()
                .filter(paquete -> paquete.getIdDestino() == idDestino)
                .collect(Collectors.toList());
    }
}