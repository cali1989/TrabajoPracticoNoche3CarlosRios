package repositories;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import connectors.Connector;
import entities.Cliente;

public class ClienteRepository {
    private Connection conn = Connector.getConnection();

    public void save(Cliente cliente) {
        if (cliente == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO Clientes (nombre, apellido, email, telefono) VALUES (?, ?, ?, ?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getApellido());
            ps.setString(3, cliente.getEmail());
            ps.setString(4, cliente.getTelefono());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                cliente.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Cliente cliente){
        if(cliente == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM Clientes WHERE id = ?")) {
            ps.setInt(1, cliente.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Cliente> getAll() {
        List<Cliente> list = new ArrayList();
        try (ResultSet rs = conn
                .createStatement()
                .executeQuery("SELECT * FROM Clientes")) {
            while (rs.next()) {
                list.add(new Cliente(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("email"),
                        rs.getString("telefono")));
                        
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Cliente getById(int id){
        return getAll()
                .stream()
                .filter(cliente -> cliente.getId() == id)
                .findFirst()
                .orElse(new Cliente());
    }

    public Cliente getByEmail(String email){
        return getAll()
                .stream()
                .filter(cliente -> cliente.getEmail().equalsIgnoreCase(email))
                .findFirst()
                .orElse(new Cliente());
    }
}

