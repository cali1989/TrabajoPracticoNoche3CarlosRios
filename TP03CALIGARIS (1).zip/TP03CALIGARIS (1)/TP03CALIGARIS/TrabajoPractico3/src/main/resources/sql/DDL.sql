-- Active: 1718839475313@@127.0.0.1@3306
DROP DATABASE IF EXISTS turismo;


CREATE DATABASE turismo;


USE turismo;


CREATE TABLE Destinos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    pais VARCHAR(50) NOT NULL,
    ciudad VARCHAR(50) NOT NULL,
    descripcion TEXT NOT NULL,
    activo BOOLEAN DEFAULT TRUE
);


CREATE TABLE Paquetes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    descripcion TEXT NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    idDestino INT NOT NULL,
    activo BOOLEAN DEFAULT TRUE
    );


CREATE TABLE Clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    apellido VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    telefono VARCHAR(20) NOT NULL,
    activo BOOLEAN DEFAULT TRUE
);


CREATE TABLE Reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    idCliente INT NOT NULL,
    idPaquete INT NOT NULL,
    fechaInicio DATE NOT NULL,
    fechaFin DATE NOT NULL,
    numPersonas INT NOT NULL ,
    precio DOUBLE(10,2) NOT NULL,
    activo BOOLEAN DEFAULT TRUE
    );


ALTER TABLE Paquetes
ADD CONSTRAINT FK_Paquetes_Destinos
FOREIGN KEY (idDestino) 
REFERENCES Destinos(id);



ALTER TABLE Reservas
ADD CONSTRAINT FK_Reservas_Clientes
FOREIGN KEY (idCliente) 
REFERENCES Clientes(id);

ALTER TABLE Reservas
ADD CONSTRAINT FK_Reservas_Paquetes
FOREIGN KEY (idPaquete) 
REFERENCES Paquetes(id);


