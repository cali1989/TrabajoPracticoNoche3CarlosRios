-- Active: 1718839475313@@127.0.0.1@3306

-- 1. Obtener el nombre y apellido de los clientes junto con el nombre del paquete que reservaron:
SELECT Clientes.nombre, Clientes.apellido, Paquetes.nombre AS nombre_paquete
FROM Clientes
INNER JOIN Reservas ON Clientes.id = Reservas.idCliente
INNER JOIN Paquetes ON Reservas.idPaquete = Paquetes.id;

-- 2. Obtener todos los destinos activos con su respectiva descripción:
SELECT nombre, descripcion
FROM Destinos
WHERE activo = TRUE;

-- 3. Obtener el nombre de los paquetes junto con su precio y el destino al que corresponden:
SELECT Paquetes.nombre, Paquetes.precio, Destinos.nombre AS nombre_destino
FROM Paquetes
INNER JOIN Destinos ON Paquetes.idDestino = Destinos.id;

-- 4. Obtener la cantidad de reservas por destino:
SELECT Destinos.nombre, COUNT(Reservas.id) AS cantidad_reservas
FROM Destinos
INNER JOIN Paquetes ON Destinos.id = Paquetes.idDestino
INNER JOIN Reservas ON Paquetes.id = Reservas.idPaquete
GROUP BY Destinos.nombre;

-- 5. Obtener el total de ingresos por cada paquete vendido:
SELECT Paquetes.nombre, SUM(Reservas.precio) AS total_ingresos
FROM Paquetes
INNER JOIN Reservas ON Paquetes.id = Reservas.idPaquete
GROUP BY Paquetes.nombre;

-- 6. Obtener una lista de clientes que no han hecho ninguna reserva:
SELECT Clientes.nombre, Clientes.apellido
FROM Clientes
LEFT JOIN Reservas ON Clientes.id = Reservas.idCliente
WHERE Reservas.id IS NULL;